<?php

//SITE GLOBAL CONFIGURATION
$email = "davidareizza@gmail.com";   //<-- Your email

?>
